package com.shpp.p2p.cs.dcharoian.assignment5;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Assignment5Part4 {

    public static void main(String[] args) {
        extractColumn("/C:\\Users\\Karel\\src\\country.txt", 1);
    }

    private static ArrayList<String> extractColumn(String filename, int line) {
        String[] subStr;
        String lineRead;
        //creating array list
        ArrayList<String> words = new ArrayList<>();
        try {
            BufferedReader reader1 = new BufferedReader(new FileReader(filename));
            //while file not end
            while ((lineRead = reader1.readLine()) != null) {
                //split string with regex
                subStr = lineRead.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
                //add string to array list
                words.add(subStr[line]);
            }
            System.out.println(words);
            reader1.close();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
            return null;
        }
        return words;
    }
}
