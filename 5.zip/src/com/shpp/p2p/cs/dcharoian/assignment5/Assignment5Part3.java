package com.shpp.p2p.cs.dcharoian.assignment5;

import com.shpp.cs.a.console.TextProgram;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.*;

public class Assignment5Part3 extends TextProgram {

    public void run() {
        String n1 = readLine("Enter number: ");
        //the resulting word is written to an array of characters
        char[] word = n1.toCharArray();
        File file = new File("/C:\\Users\\Karel\\src\\dictionary.txt");
        try {
            FileReader fr = new FileReader(file);
            //create a BufferedReader from an existing FileReader to read line by line
            BufferedReader reader1 = new BufferedReader(fr);
            // count the first row first
            String line = reader1.readLine();
            //read all rows
            while (line != null) {
                int count = 0;
                for (char c : word) {
                    if (line.indexOf(c) >= 0) {
                        count++;
                    }
                }
               // if there are 3 matches out of 3
                if (count == 3) {
                    System.out.println(line);
                    run();
                }
                line = reader1.readLine();

            }

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
}


