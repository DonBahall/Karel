package com.shpp.p2p.cs.dcharoian.assignment5;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;


public class Assignment5Part4 {

    private static final int NUM_OF_COL = 8;

    public static void main(String[] args) {
        extractColumn("/C:\\Users\\Karel\\src\\country.txt", 1);
    }

    private static ArrayList<String> extractColumn(String filename, int line) {
        //open file
        File file = new File(filename);
        String[] subStr;

        String lineRead;
        ArrayList<String> words = new ArrayList<>();
        try {
            FileReader fr = new FileReader(file);
            BufferedReader reader1 = new BufferedReader(fr);
            for (int j = 1; j < NUM_OF_COL; j++) {
                lineRead = reader1.readLine();
                //use regular expression to split string
                subStr = lineRead.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
                words.add(subStr[line]);
            }
            System.out.println(words);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
            return null;
        }
        return words;
    }
}
